# AutoForge Infrastructure Scan Report

**Generated:** 2025-07-08 17:35:33

## sample.tf

- 🔍 Found resource: azurerm_storage_account at line 1
- ✅ Approved region: eastus at line 3
- ⚠️ Missing required tag key: 'owner'
- ⚠️ Missing required tag key: 'env'

**Compliance Score:** 25%
✅ Passed: 1  |  ⚠️ Warnings: 2  |  🚫 Failed: 0

---
